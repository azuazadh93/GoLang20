package main
import (
"fmt"
"os"
"strconv"
)
func main() {
//name:=os.Args[1]
m1:=os.Args[2]
m2:=os.Args[3]
m3:=os.Args[4]
i1,err:=strconv.ParseInt(m1,0,64)
i2,err:=strconv.ParseInt(m2,0,64)
i3,err:=strconv.ParseInt(m3,0,64)
if err==nil{
    fmt.Println("The sum is",i1+i2+i3)
    fmt.Println("The avg is",(i1+i2+i3)/3)

}
