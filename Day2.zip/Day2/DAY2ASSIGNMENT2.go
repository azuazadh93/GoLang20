package main
import "fmt"

func main() {
    var a [10] int
   var highest,lowest int
   fmt.Println("enter the marks of 10 students")
   for i:=0;i<10;i++ {
    fmt.Scanln(&a[i])

}
    highest=maxfun(a)
    lowest=minfun(a)

   fmt.Println(highest,lowest)
   }
   
   func maxfun(n[10] int) int{
    for i:=0;i<10;i++ {
        for j:=i+1;j<10;j++ {
            if(n[i]<n[j]) {
                temp:=n[i]
                n[i]=n[j]
                n[j]=temp
            }
        }
    }
    h:=n[0]
    
    return h
   } 

   func minfun(n[10] int) int {
    for i:=0;i<10;i++ {
        for j:=i+1;j<10;j++ {
            if(n[i]<n[j]) {
                temp:=n[i]
                n[i]=n[j]
                n[j]=temp
            }
        }
    }
  
    l:=n[9]
    return l
   } 