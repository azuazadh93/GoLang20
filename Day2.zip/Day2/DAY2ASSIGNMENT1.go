package main
import "fmt"
func main() {
	fmt.Println("Enter the number")
	var a int
	fmt.Scanln(&a)
	Result:= answer(a)
	fmt.Println("The answer is",Result)
}
func answer(a int) int {
	var i int
	fact:=1
	for i=1;i<=a;i++ {
	fact=fact*i
	}
	return fact
}