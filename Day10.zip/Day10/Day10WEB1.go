package main
import(
	"fmt"
	"net/http"
	"github.com/gorilla/mux"
)

type book struct{
	id string
	name string
}

func main(){
	b:=book{}
	r:=mux.NewRouter()
	r:=HandleFunc("/book/{id}/name/{name}", 
	func (w http.ResponseWriter, r *http.Request){

		vars:= mux.Vars(r)
		b.id:=vars["id"]
		b.name:= vars["name"]
		 fmt.Fprintf(w, "You are requested %s and %s  \n", b.id,b.name)
		 fmt.Println(b)
	})
	fmt.Printf("Server is ready in 8089")
	http.ListenAndServe(":8089",r)
}
