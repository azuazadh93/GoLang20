package main
import ("fmt"
        "html/template"
		"net/http"
	//	"encoding/json"
	"strconv"
	//helper "./helpers"
	)

	type Show struct {
		ShowTime int
		ShowName string
		Date string
		Tickets int
	 }
	 
func main(){

show:=[]Show{
	 Show{ShowTime:1000,ShowName:"Kaala",Date:"19th Dec 2017",Tickets:250},
	 Show{ShowTime:1300,ShowName:"Black Panther",Date:"18th Dec 2017",Tickets:200},
	 Show{ShowTime:1600,ShowName:"Avengers",Date:"17th Dec 2017",Tickets:250},
	 Show{ShowTime:1900,ShowName:"Lie",Date:"16th Dec 2017",Tickets:200},
	 Show{ShowTime:2200,ShowName:"Rangasthalam",Date:"15th Dec 2017",Tickets:250},
	 Show{ShowTime:1000,ShowName:"Fida",Date:"14th Dec 2017",Tickets:150},
	 Show{ShowTime:1300,ShowName:"Ninnu Kori",Date:"13th Dec 2017",Tickets:250},
	 Show{ShowTime:1600,ShowName:"Gabbar Singh ",Date:"12th Dec 2017",Tickets:100},
	 Show{ShowTime:1900,ShowName:"Kaaja",Date:"11th Dec 2017",Tickets:250},
	 Show{ShowTime:2200,ShowName:"Boom Boom",Date:"10th Dec 2017",Tickets:200},

 }

var x string
 tmpl:=template.Must(template.ParseFiles("proj.html"))
http.HandleFunc("/",func(w http.ResponseWriter,r *http.Request){
	if r.Method!=http.MethodPost{
		tmpl.Execute(w,nil)
	}
	
var flag int
	x=r.FormValue("movie")
	//movieCheck:=helper.IsEmpty(x)
	
	//if movieCheck{
	 //  fmt.Fprintf(w,"Error : There is empty data")
	//	return
	//}
//	fmt.Printf(x)
	for _,y:=range show{
		if y.ShowName==x{
			flag=1
			break	

		}
	}


	if(flag==1){                
		//fmt.Println("Show is available")
	//	fmt.Fprintf(w,"Show is available")
		http.Redirect(w,r,"/det",http.StatusMovedPermanently)
	}else if (flag==0){
		fmt.Fprintf(w,"Show is not available")
	}

})


http.HandleFunc("/det",func(w http.ResponseWriter,r *http.Request,){

	tmpl:=template.Must(template.ParseFiles("go.html"))
		if r.Method!=http.MethodPost{
			tmpl.Execute(w,nil)
		}
var falg int
fmt.Printf(x)
z:=r.FormValue("date")
for _,y:=range show{
	if y.Date==z {
		falg=1
		break	
	fmt.Println(y.Date)   
	fmt.Println(y.ShowName)                                            
	}
}

//fmt.Println(x)

//fmt.Println(z)

if(falg==1){                
	//fmt.Fprintf(w,"Tickets are available")
	http.Redirect(w,r,"/final",http.StatusMovedPermanently)


}else if (falg==0){
	fmt.Fprintln(w,"Tickets are not available")
}


	})

	http.HandleFunc("/final",func(w http.ResponseWriter,r *http.Request){
		tmpl:=template.Must(template.ParseFiles("get.html"))
		if r.Method!=http.MethodPost{
			tmpl.Execute(w,nil)
		}	
		

		a:=r.FormValue("tick")

		s,_:=strconv.Atoi(a)
	var fg int
for _,v:=range show{
	if(s<v.Tickets){
		fg=1
	}
}


if fg==1{
fmt.Fprintf(w,"Tickets available")
}else{
	fmt.Fprintf(w,"Tickets not available")
}
	
	})
fmt.Printf("listening...8088")
http.ListenAndServe(":8088",nil)

}



/*func main(){
    tmpl:=template.Must(template.ParseFiles("employee.html"))
    http.HandleFunc("/",func(w http.ResponseWriter,r *http.Request){

if r.Method!=http.MethodPost{
    tmpl.Execute(w,nil)
    return 
}

i,_:=strconv.Atoi(r.FormValue("ID"))
f,_:=strconv.ParseFloat(r.FormValue("Phone"),64)


details:=employee{
            ID:i,
            Name:r.FormValue("Name"),
            Department:r.FormValue("Department"),
            Doj:r.FormValue("Doj"),
            Email:r.FormValue("Email"),
			Phone:f,
}


fmt.Println(details)
//tmpl.Execute(w,true)
json.NewEncoder(w).Encode(details)
	})


 fmt.Printf("listening...8088")
	http.ListenAndServe(":8088",nil)

} */



